## Key Vault Rotation Function for SQL admin password Changelog

<a name="keyvault-rotation-sqlpassword-csharp"></a>
# keyvault-rotation-sqlpassword-csharp (2020-12-28)

*Features*
* Rotation function for sql password triggered by Event Grid (AKVSQLRotation)

* Rotation function for sql password triggered by HTTP call(AKVSQLRotationHttp)

* ARM template for function deployment

* ARM template for adding sql password  to existing function

*Bug Fixes*


*Breaking Changes*

